"""World API transport adapters."""
